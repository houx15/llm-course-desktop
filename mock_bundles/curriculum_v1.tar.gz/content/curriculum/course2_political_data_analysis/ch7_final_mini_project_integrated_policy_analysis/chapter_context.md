# 第七章：期末 Mini-Project —— 综合公共政策数据分析

## 章节概述

在前六章中，你已经依次完成了以下能力建设：

- 建立可复现的数据分析工作流（Colab + Drive）
- 使用 Python 与 pandas 处理真实公共政策数据
- 构建时间变量并复现 GovTrack 官方趋势图
- 对政治文本进行清洗、探索性分析
- 使用 TF-IDF、相似性、聚类与主题模型分析文本

本章不再教授任何新工具。

本章的唯一目标是：

> **独立完成一次“完整、可解释、可复现”的公共政策数据分析。**

你将使用 **同一个 GovTrack 国会不端行为数据集**，完成一份结构完整的分析型 Notebook。

---

## Mini-Project 的核心要求

你的最终 Notebook 必须体现以下三点：

1. **复现（Replication）**
   - 你能够重现 GovTrack 官网中的核心统计逻辑

2. **扩展（Extension）**
   - 你使用文本分析方法，提出并回答一个新的分析问题

3. **解释（Interpretation）**
   - 你能够用政策与制度语言解释结果，而不是只展示技术输出

---

## 使用的数据集（再次确认）

### 数据集名称
**Congressional Misconduct Dataset**

### 官方来源
- GitHub：https://github.com/govtrack/misconduct
- GovTrack 网站：https://www.govtrack.us/misconduct

### 数据格式
- 原始数据文件：`misconduct.yaml`
- 一条记录 = 一起国会不端行为实例（不等于定罪）

### 重要提醒（必须在项目中体现）

- 指控 ≠ 定罪  
- 文本相似 ≠ 行为相同  
- 模型结果 ≠ 事实真相  

这些方法论限制必须在你的分析中被明确提及。

---

## 项目结构要求（强制）

你的 Notebook **必须**包含以下结构性部分（以 Markdown 标题区分）：

1. Introduction & Research Question  
2. Data & Methodology  
3. Replication Analysis (GovTrack-style)  
4. Text Analysis Extension  
5. Discussion & Limitations  

---

## 允许与不允许的事情

### 允许
- 查阅文档
- 参考课堂 Notebook
- 复用自己之前写过的代码

### 不允许
- 直接复制他人完整 Notebook
- 只给代码、不给解释
- 只做词云或模型，不回答任何问题

---

## 学习方式

- 本章为 **独立完成**
- 教师仅提供：
  - 方向性反馈
  - 方法论提醒
- 不提供逐步代码提示

---

## 预计时长

- 项目完成时间：2–4 小时（可分多次完成）
