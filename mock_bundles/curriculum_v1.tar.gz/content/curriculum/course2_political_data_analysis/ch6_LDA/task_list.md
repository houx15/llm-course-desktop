# 第六章任务列表

## 任务类型说明

- **核心任务（Core）**：必须完成
- **可选任务（Optional）**：用于深入探索
- **脚手架任务（Scaffolding）**：用于支持理解或排错

---

## 核心任务（必须完成）

### 任务1：构建 LDA 所需的词频矩阵
- **build_dtm_for_lda** [类型: core]
  - 使用 `CountVectorizer`
  - 输入文本：`clean_text`
  - 设置合理的 `min_df` / `max_df`
  - 输出：
    - document–term matrix 的形状
    - 词汇表大小
  - 回答：
    - 为什么不用 TF-IDF 直接做 LDA？

---

### 任务2：拟合 LDA 模型
- **fit_lda_model** [类型: core]
  - 固定主题数量（K = 5 或 6）
  - 使用 `LatentDirichletAllocation`
  - 训练模型并保存结果
  - 输出：
    - 每个主题的前 10 个高权重词

---

### 任务3：主题的政治学解释
- **interpret_topics** [类型: core]
  - 为每个主题填写解释表格：

    | Topic ID | Top Words | Political Interpretation |
    |---------|-----------|--------------------------|

  - 解释应指向：
    - 制度过程
    - 行为领域
    - 权力关系
  - 避免只复述词本身

---

### 任务4：为每条案件分配主题权重
- **assign_topic_distribution** [类型: core]
  - 获取每条文档的 topic distribution
  - 将其加入原 DataFrame
  - 确定每条案件的 dominant topic

---

### 任务5：主题随时间变化
- **topic_trends_over_time** [类型: core]
  - 按 decade（基于 first_cons_year）分组
  - 计算每个主题的平均权重
  - 绘制折线图或 stacked area 图
  - 回答：
    - 哪些主题在上升？
    - 哪些在下降？

---

## 可选任务（探索性）

### 可选1：主题 × misconduct_type
- **topic_by_type** [类型: optional]
  - 比较不同 misconduct_type 的主题分布
  - 判断哪些主题高度集中于某一类型

### 可选2：主题 × 后果严重性
- **topic_and_consequences** [类型: optional]
  - 将主题与 consequence tags 关联
  - 比较不同主题对应的制度处理结果

---

## 脚手架任务（如需要）

- **install_sklearn** [类型: scaffolding]
  - 安装或排查 scikit-learn
- **inspect_topic_words** [类型: scaffolding]
  - 调试主题词输出顺序与权重
- **debug_sparse_matrix** [类型: scaffolding]
  - 处理空文本或极短文本导致的问题

---

## 任务完成标准（简要）

- 成功训练 LDA 模型
- 为每个主题给出合理、可辩护的政治学解释
- 至少完成一次：
  - 主题 × 时间 的比较
