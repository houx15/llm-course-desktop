# 第四章任务列表

## 任务类型说明

- **核心任务（Core）**：必须完成
- **可选任务（Optional）**：用于加深理解
- **脚手架任务（Scaffolding）**：用于支持核心任务

---

## 核心任务（必须完成）

### 任务1：比较 allegation 与 text 两种文本字段
- **compare_text_fields** [类型: core]
  - 随机抽取 3 条记录
  - 同时展示 `allegation` 与 `text`
  - 用 Markdown 回答：
    - 两者在长度、信息量上的差异
    - 为什么 `text` 更适合文本分析？

---

### 任务2：构建清洗后的文本列
- **clean_text_field** [类型: core]
  - 对 `text` 进行最小必要清洗：
    - 转为小写
    - 去除标点与多余符号
    - 去除 stopwords（可使用英文标准 stopwords）
  - 创建新列：`clean_text`
  - 展示清洗前后同一条记录的对比

---

### 任务3：词频统计（by misconduct type）
- **word_frequency_by_type** [类型: core]
  - 按 `misconduct_type` 分组
  - 对 `clean_text` 进行分词
  - 统计每一类中最常见的前 20 个词
  - 输出为表格，而不是图像

---

### 任务4：绘制词云（Word Cloud）
- **plot_wordclouds** [类型: core]
  - 为至少两种不同的 `misconduct_type` 绘制词云
  - 使用相同的参数设置（便于比较）
  - 在 Markdown 中回答：
    - 哪些词最显眼？
    - 哪些词你认为是“制度性噪音”？

---

### 任务5：构建并分析 n-grams
- **ngram_analysis** [类型: core]
  - 构建：
    - bigrams（2-gram）
    - trigrams（3-gram）
  - 统计出现频率最高的短语
  - 比较：
    - n-gram 与单词词频的差异
    - 哪一种更接近“政治表达”？

---

## 可选任务（探索性）

### 可选1：时间对比词云
- **wordcloud_by_time** [类型: optional]
  - 将数据分为早期（如 <1950）与近期（如 ≥2000）
  - 比较词云差异

### 可选2：allegation 的 n-gram 分析
- **allegation_ngram** [类型: optional]
  - 对 `allegation` 字段单独做 n-gram
  - 与 `text` 的结果进行对比

---

## 脚手架任务（如需要）

- **install_wordcloud** [类型: scaffolding]
  - 安装 `wordcloud` 库
- **debug_tokenization** [类型: scaffolding]
  - 排查空文本、NaN 导致的问题
- **inspect_stopwords** [类型: scaffolding]
  - 查看 stopwords 列表，理解其作用

---

## 任务完成标准（简要）

- 成功生成清洗后的文本列
- 至少生成：
  - 一张词频表
  - 两张词云图
  - 一组 n-gram 统计结果
- 能清楚说明这些结果“能说明什么，不能说明什么”
