# 第五章任务列表

## 任务类型说明

- **核心任务（Core）**：必须完成
- **可选任务（Optional）**：用于深化理解
- **脚手架任务（Scaffolding）**：用于支持理解或排错

---

## 核心任务（必须完成）

### 任务1：构建 TF-IDF 文本向量
- **build_tfidf_matrix** [类型: core]
  - 使用 `TfidfVectorizer`
  - 输入文本：`clean_text`
  - 设定合理的参数（如 `min_df`, `max_df`）
  - 输出：
    - TF-IDF 矩阵的形状
    - 特征（词）数量
  - 用 Markdown 回答：
    - “矩阵的一行、一列分别代表什么？”

---

### 任务2：文本相似性检索
- **text_similarity_search** [类型: core]
  - 随机选择一条不端行为案例
  - 计算它与所有其他案例的 cosine similarity
  - 找出最相似的前 5 条案例
  - 展示：
    - allegation
    - misconduct_type
    - 相似度数值
  - 用文字解释：为什么它们看起来“相似”？

---

### 任务3：案例级聚类（Clustering）
- **cluster_cases** [类型: core]
  - 使用 K-Means（k = 5 或 6）
  - 为每条案例分配 cluster label
  - 将 label 加入 DataFrame
  - 统计每个 cluster 中：
    - misconduct_type 的分布
    - 案例数量

---

### 任务4：解释聚类结果
- **interpret_clusters** [类型: core]
  - 对每个 cluster：
    - 提取 TF-IDF 权重最高的前 10 个词
    - 随机查看 2–3 条原始文本
  - 用 Markdown 回答：
    - 这个 cluster 可能代表哪类“叙事模式”？
    - 它是否与某些 misconduct_type 重合？

---

## 可选任务（探索性）

### 可选1：相似性随时间变化
- **similarity_over_time** [类型: optional]
  - 比较：
    - 早期（如 <1950）
    - 近期（如 ≥2000）
  - 判断文本相似性是否随时间收敛或分化

### 可选2：不同 k 值的比较
- **compare_k_values** [类型: optional]
  - 比较 k=4, 6, 8 的聚类结果
  - 观察稳定性变化

---

## 脚手架任务（如需要）

- **install_sklearn** [类型: scaffolding]
  - 如果无法导入 sklearn
- **inspect_sparse_matrix** [类型: scaffolding]
  - 查看 TF-IDF 稀疏矩阵的非零比例
- **debug_vectorizer** [类型: scaffolding]
  - 排查空文本或 NaN 导致的问题

---

## 任务完成标准（简要）

- 成功构建 TF-IDF 矩阵
- 至少完成一次：
  - 相似性检索
  - 聚类分析
- 能清楚解释“相似”和“聚类”在本语境中的含义
