# 第二章任务列表

## 任务类型说明

- **核心任务（Core）**：必须完成
- **脚手架任务（Scaffolding）**：用于理解或调试

---

## 核心任务（必须完成）

### 任务1：理解 Python 的基础数据类型
- **inspect_python_types** [类型: core]
  - 对以下对象使用 `type()`：
    - 一个年份
    - 一条 allegation 文本
    - tags 字段
    - consequences 字段
  - 用 Markdown 写出每个对象对应的 Python 类型
  - 回答：为什么 `consequences` 不是字符串？

---

### 任务2：字符串 → 列表（处理 tags）
- **split_tags_field** [类型: core]
  - 使用字符串方法将 `tags` 列拆分为列表
  - 创建新列 `tag_list`
  - 验证新列中每个单元格都是 `list` 类型
  - 随机抽取 3 行展示结果

---

### 任务3：从列表中提取分析变量
- **extract_tag_information** [类型: core]
  - 从 `tag_list` 中提取：
    - 一个“不端行为类型”（如 corruption, elections 等）
    - 一个“案件状态”（resolved / unresolved）
  - 创建两个新列：
    - `misconduct_type`
    - `case_status`
  - 验证这两列的唯一值集合（`unique()`）

---

### 任务4：理解 DataFrame 的行与列
- **row_column_reasoning** [类型: core]
  - 使用 `.loc[]` 查看一整行
  - 使用 `df['column']` 查看一整列
  - 回答：
    - 一行代表什么？
    - 一列代表什么？
  - 用自己的话写下答案（至少 4 句话）

---

## 可选任务（探索性）

### 可选1：字典的结构（consequences）
- **inspect_consequence_dict** [类型: optional]
  - 随机查看一条 consequence（字典）
  - 打印其 keys
  - 用自然语言解释每个 key 的含义

### 可选2：简单计数
- **count_by_type** [类型: optional]
  - 使用 `value_counts()` 统计不同 misconduct_type 的数量
  - 判断哪一类最常见

---

## 脚手架任务（如需要）

- **review_string_methods** [类型: scaffolding]
  - 练习 `split()`, `lower()`
- **debug_type_error** [类型: scaffolding]
  - 排查 “list has no attribute …” 等常见错误

---

## 任务完成标准（简要）

- 所有核心任务完成
- 每一步操作都能说明：
  - 输入是什么
  - 输出是什么
  - 为什么要这样转换
