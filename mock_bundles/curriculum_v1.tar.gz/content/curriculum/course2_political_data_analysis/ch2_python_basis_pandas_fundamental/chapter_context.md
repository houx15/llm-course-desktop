# 第二章：Python 数据类型与 pandas 基础操作

## 章节概述

在第一章中，你已经能够在 Colab 中成功加载 GovTrack 的国会不端行为数据集，并理解了它在政治学上的含义。

从本章开始，我们将进入真正的“写代码”阶段。但请注意：  
**我们学习 Python 的目的不是成为程序员，而是让政治数据变得可操作、可分析。**

本章将系统介绍 Python 中最常见、也是数据分析中最重要的数据类型，并引导你理解 pandas 是如何在这些基础类型之上工作的。

---

## 学习目标

完成本章后，你将能够：

1. **理解并区分 Python 的核心数据类型**
   - `int`, `float`, `str`
   - `list`, `dict`
   - 知道它们各自适合表示什么样的政治信息

2. **理解 pandas DataFrame 的结构**
   - DataFrame 是“由列组成的表”
   - 每一列本质上是一个 Series
   - 每一行代表一个政治事件实例（延续第一章的理解）

3. **对 GovTrack misconduct 数据进行基础结构化处理**
   - 将 `tags` 从字符串转换为列表
   - 从复杂结构中提取“可分析”的变量

---

## 前置知识

- 已完成第一章所有核心任务
- 能在 Colab 中运行代码
- 能成功加载 `misconduct.yaml` 并得到一个 DataFrame

本章**不要求**任何 Python 编程经验。

---

## 实践环境

- Google Colab
- Python 3（Colab 默认）
- 使用的核心库：
  - `pandas`
  - `pyyaml`

---

## 目标数据集（延续使用）

### 数据集名称
**Congressional Misconduct Dataset**

### 官方来源
- GitHub：https://github.com/govtrack/misconduct
- 数据文件：`misconduct.yaml`

### 本章重点使用的字段

- `tags`：空格分隔的字符串  
  示例："corruption elections resolved"
  - `consequences`：由字典组成的列表
- `allegation`：简短文本字符串

这些字段非常适合用来理解 **Python 数据类型与数据结构**。

---

## Python 数据类型的政治学直觉（重要）

| Python 类型 | 直觉理解 | 在本数据中的例子 |
|-----------|----------|----------------|
| `int` | 计数 / 年份 | 年份、索引 |
| `str` | 文字描述 | allegation, tags |
| `list` | 多个事物的集合 | consequences, tag 列表 |
| `dict` | 带标签的信息 | 单条 consequence |
| `DataFrame` | 事件表 | 所有 misconduct 实例 |

---

## 学习方式

- 每个概念都**立即配合真实数据操作**
- 不要求记忆语法，但要求：
- 看懂代码在“对数据做什么”
- 能用自己的话解释结果
- 所有任务都围绕 GovTrack 数据展开，不使用玩具示例

---

## 预计时长

- 核心任务：60–75 分钟
- 对零基础学习者来说，这是第一章“真正费脑力”的内容

