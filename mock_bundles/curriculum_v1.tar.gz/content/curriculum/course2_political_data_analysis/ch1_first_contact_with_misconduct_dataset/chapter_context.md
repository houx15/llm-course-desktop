# 第一章：Colab工作流与政治不端行为数据初探

## 章节概述

本章是整门课程的起点，目标不是“分析数据”，而是**建立一个可靠、可复现的数据分析工作环境**，并帮助你第一次接触我们将贯穿全课程使用的真实政治学数据集。

你将学习如何：

- 在 Google Colab 中运行 Python 代码
- 将数据保存到你的 Google Drive 中，避免数据丢失
- 正确理解一个真实公共政策数据集中“一行数据代表什么”

本章结束时，你应该能够**独立在 Colab 中加载 GovTrack 的国会不端行为数据集，并清楚它记录的是什么、又不是什么**。

---

## 学习目标

完成本章后，你将能够：

1. **正确使用 Google Colab**
   - 区分代码单元（Code Cell）与文本单元（Markdown Cell）
   - 理解 Colab 的“临时运行环境”特性

2. **建立稳定的数据存储路径**
   - 将 Google Drive 挂载到 Colab
   - 在 Drive 中创建课程专用数据目录

3. **加载并初步理解 GovTrack 不端行为数据集**
   - 从 GitHub 下载原始数据文件
   - 使用 Python 读取 YAML 格式的数据
   - 明确：一条记录代表“一起不端行为实例（instance）”

---

## 前置知识

- 不要求任何编程经验
- 不要求使用过 Colab
- 你只需要：
  - 会使用浏览器
  - 理解“文件”“文件夹”的基本概念

---

## 实践环境

你将使用以下环境完成本章：

- **Google Colab（云端 Jupyter Notebook）**
- **Python 3（Colab 已预装）**
- 主要使用的 Python 库：
  - `pandas`
  - `pyyaml`

你**不需要**在本地安装任何软件。

---

## 本课程使用的目标数据集（非常重要）

### 数据集名称
**Congressional Misconduct Dataset**

### 官方来源
- GitHub 仓库：https://github.com/govtrack/misconduct
- 官方可视化页面：https://www.govtrack.us/misconduct

### 数据格式
- 主数据文件为：`misconduct.yaml`
- 文件格式：**YAML（不是 CSV）**

### 数据记录的基本单位（必须理解）

> **一条记录（one record） = 一起国会议员不端行为或被指控的不端行为实例（instance）**

⚠️ 注意：
- 这 **不是** “一次投票”
- 这 **不是** “一条新闻”
- 这 **也不一定意味着违法或定罪**

---

## 核心字段说明（第一章只要求理解，不要求熟记）

在 `misconduct.yaml` 中，每条记录通常包含以下字段：

- `person`：GovTrack 内部使用的议员 ID（数字）
- `name`：议员姓名（用于人类阅读，不是分析主键）
- `allegation`：一句简短描述，用来完成句子  
  > “The member was accused of …”
- `text`：对该不端行为的详细文字说明（Markdown 格式）
- `tags`：用空格分隔的一组标签  
  - 包含 **不端行为类型**（如 `corruption`, `elections`, `ethics` 等）
  - 以及案件状态（`resolved` 或 `unresolved`）
- `consequences`：一个列表，记录该事件引发的正式后果（如果有）

⚠️ 本课程会**严格区分**：
- 不端行为的**指控内容**
- 国会或法院的**正式处理结果**

---

## 学习方式

本章采用 **“环境优先、理解优先”** 的方式：

- 你将亲手完成每一步设置
- 不会直接给出完整代码，而是提供清晰的操作目标
- 每一步都要求你验证结果是否符合预期

---

## 预计时长

- 核心任务：45–60 分钟
- 如果你是第一次使用 Colab，可能需要更长时间，这是正常的
