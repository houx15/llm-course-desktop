# 第一章任务列表

## 任务类型说明

- **核心任务（Core）**：本章必须完成的任务
- **脚手架任务（Scaffolding）**：为核心任务提供必要支持

---

## 核心任务（必须完成）

### 任务1：设置 Google Colab 与 Google Drive 工作环境
- **setup_colab_drive** [类型: core]
  - 在 Colab 中运行代码，将 Google Drive 挂载到运行环境
  - 在 Drive 中创建一个用于本课程的数据文件夹
  - 验证该文件夹可以被 Python 正确访问

---

### 任务2：从 GovTrack GitHub 仓库下载原始数据
- **download_dataset** [类型: core]
  - 使用命令行工具（如 `wget`）下载 `misconduct.yaml`
  - 将文件保存到你刚刚创建的 Drive 数据目录中
  - 验证文件存在且大小不为 0

---

### 任务3：读取 YAML 数据并构建初始 DataFrame
- **load_yaml_data** [类型: core]
  - 使用 `yaml.safe_load()` 读取 `misconduct.yaml`
  - 理解读取后数据的 Python 类型（list / dict）
  - 使用 `pandas.json_normalize()` 构建 DataFrame
  - 打印 DataFrame 的行数和列名

---

### 任务4：验证“数据实例”的含义
- **understand_instance_unit** [类型: core]
  - 随机查看 3 条记录
  - 对每条记录回答：
    - 这一行描述的是谁？
    - 是什么类型的不端行为？
    - 是否已经有正式后果？
  - 用 Markdown 写下你的观察结论（至少 5 句话）

---

## 脚手架任务（如需要）

以下任务可能在某些情况下需要完成：

- **install_dependencies** [类型: scaffolding]
  - 如果导入 `yaml` 失败，安装 `pyyaml`
- **check_drive_path** [类型: scaffolding]
  - 排查路径错误（如拼写错误、权限问题）
- **print_raw_structure** [类型: scaffolding]
  - 直接打印 YAML 的原始 Python 结构，辅助理解

---

## 任务完成标准（简要）

- 所有核心任务均需完成
- 每个任务必须有：
  - 可运行的代码
  - 可验证的输出
  - 简要的文字说明
