# 第三章任务列表

## 任务类型说明

- **核心任务（Core）**：必须完成
- **脚手架任务（Scaffolding）**：用于辅助理解或调试

---

## 核心任务（必须完成）

### 任务1：展开 consequences 并提取日期
- **explode_consequences** [类型: core]
  - 使用 `explode()` 将 consequences 列展开
  - 得到一个“后果级别”的 DataFrame
  - 使用 `pd.json_normalize()` 提取 `date` 与 `tags`
  - 验证：一行代表“一次正式制度后果”

---

### 任务2：处理不完整日期并提取年份
- **parse_consequence_year** [类型: core]
  - 将 `date` 字段转换为字符串
  - 从中提取年份（int）
  - 创建新列 `cons_year`
  - 验证：是否存在缺失年份？为什么？

---

### 任务3：计算每个实例的 first consequence year
- **compute_first_cons_year** [类型: core]
  - 对同一 misconduct 实例的多个 consequences：
    - 选取最早的年份
  - 将结果合并回原始实例级 DataFrame
  - 创建列：`first_cons_year`

---

### 任务4：按时间与不端行为类型聚合
- **aggregate_by_time_and_type** [类型: core]
  - 将年份转换为“十年（decade）”
  - 使用 `groupby()` 统计：
    - 每个 decade × misconduct_type 的实例数量
  - 输出一个用于画图的汇总表

---

### 任务5：绘制 GovTrack 风格趋势图
- **plot_misconduct_trends** [类型: core]
  - 使用 matplotlib 或 pandas 自带绘图
  - 绘制 stacked bar chart：
    - x 轴：decade
    - y 轴：案件数量
    - stack：misconduct_type
  - 图表应清晰标注：
    - 标题
    - 轴含义
    - 图例

---

## 可选任务（探索性）

### 可选1：只分析 resolved 案件
- **filter_resolved_cases** [类型: optional]
  - 仅保留 `case_status == 'resolved'`
  - 重新绘制趋势图
  - 比较与全样本的差异

### 可选2：使用年份而非十年
- **yearly_trend** [类型: optional]
  - 按年份而非 decade 统计
  - 观察波动是否更剧烈

---

## 脚手架任务（如需要）

- **inspect_raw_dates** [类型: scaffolding]
  - 打印 10 条原始 date 字段，观察格式差异
- **debug_explode** [类型: scaffolding]
  - 排查 explode 后出现 NaN 的原因

---

## 任务完成标准（简要）

- 成功复现一个“随时间变化”的 stacked 图表
- 能明确解释：
  - 时间变量的来源
  - 每一层 stack 的含义
