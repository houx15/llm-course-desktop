# 第三章：时间维度与 GovTrack 风格趋势分析

## 章节概述

在前两章中，你已经能够：

- 正确加载 GovTrack 国会不端行为数据集
- 理解 Python 的基础数据类型
- 将非结构化的 tags 字段转换为可分析的分类变量

从本章开始，我们将进入**真正的政治数据分析阶段**。

本章的核心目标是：  
👉 **复现 GovTrack 官网中展示的“不端行为随时间变化”的统计图表**，并理解这些图表背后的制度含义。

---

## 学习目标

完成本章后，你将能够：

1. **理解“时间”在该数据集中的特殊性**
   - 不端行为往往没有单一、明确的发生日期
   - 正式后果（consequences）是制度层面最可靠的时间锚点

2. **构建用于时间分析的关键变量**
   - 从 consequences 中提取日期
   - 定义“first consequence year”作为分析时间

3. **使用 pandas 进行时间聚合与分组统计**
   - 按年份 / 十年分组
   - 按不端行为类型分组

4. **复现 GovTrack 风格的趋势图**
   - 不端行为类型随时间变化
   - 为后续“后果分析”打下结构基础

---

## 前置知识

- 已完成 Class 1 与 Class 2 的所有核心任务
- DataFrame 中已包含以下列：
  - `misconduct_type`
  - `case_status`
  - `consequences`
- 能熟练使用：
  - `groupby()`
  - `value_counts()`
  - `explode()`

---

## 本章使用的目标数据集（延续）

### 数据集名称
**Congressional Misconduct Dataset**

### 官方来源
- GitHub：https://github.com/govtrack/misconduct
- 官网可视化：https://www.govtrack.us/misconduct

### 本章关键字段说明（再次强调）

- `consequences`：  
  一个列表（list），每个元素是一个字典（dict），通常包含：
  - `date`：字符串形式的日期（可能只有年份）
  - `tags`：后果类型（如 conviction, plea, censure 等）

- `tags`（instance-level）：
  - 不端行为类型：corruption / elections / ethics / crime / sexual-harassment-abuse
  - 案件状态：resolved / unresolved

⚠️ **重要原则**：  
> 本课程中，“时间”默认指的是  
> **该事件首次进入正式制度处理流程的时间（first consequence date）**，  
而不是媒体报道时间或推测的行为发生时间。

---

## 为什么不用“行为发生时间”？

这是一个重要的政治学方法论问题：

- 很多不端行为持续多年
- 行为发生时间往往不可考或存在争议
- 制度反应（调查、起诉、惩处）才是公共权力真正介入的时间点

GovTrack 官方也采用了类似逻辑来排序和展示数据。

---

## 学习方式

- 所有统计和图表都基于 **真实数据**
- 每一步都先生成“中间表”（intermediate table），再画图
- 不追求“画得好看”，而追求：
  - 数据逻辑正确
  - 变量含义清楚

---

## 预计时长

- 核心任务：60–75 分钟
- 如果你第一次处理“嵌套列表 + 时间”，时间稍长是正常的
