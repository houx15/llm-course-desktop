# Practice Chapter 1 — Task Completion Principles

------

## Core Philosophy

This chapter evaluates **process**, not polish.

Successful completion requires demonstrating:

1. **Computational literacy**
2. **Research-oriented reasoning**
3. **Effective human–LLM collaboration**

------

## What Counts as “Completed”?

### Technical Criteria

You can show evidence that you:

- Used both Markdown and Code cells correctly
- Defined variables and functions successfully
- Ran NumPy operations on arrays (not scalars)
- Interpreted outputs rather than ignoring them
- Read and acted on error messages

------

### Conceptual Criteria

You can explain, in your own words:

- Why notebooks mix text and code
- What a library/package provides
- Why vectorized operations matter
- Why debugging is a dialogue, not a failure

------

### LLM Collaboration Criteria

You must demonstrate that you can:

- Provide **complete error messages** to an AI
- Ask specific, technical questions
- Modify AI-suggested code rather than copy blindly
- Evaluate whether a fix actually solves the problem

------

## What Does *Not* Count as Completion

- Code runs, but no explanation is given
- Errors are “fixed” without understanding why
- AI output is copied without testing
- Markdown cells are missing or empty
- Vectorization is replaced with manual loops

------

## Verification Questions (Instructor / Agent Use)

- “What exactly caused this error?”
- “Why is this operation vectorized?”
- “What would change if this were a loop?”
- “What did the LLM help you understand here?”

------

## Final Takeaway

This chapter establishes a norm for the entire course:

> **Programming is an interactive research practice,
> and LLMs are reasoning partners—not answer machines.**

Completion means you have begun to work *with* computation, not merely *around* it.