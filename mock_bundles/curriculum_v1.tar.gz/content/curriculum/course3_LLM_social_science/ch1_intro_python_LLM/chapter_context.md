# Practice Chapter 1

## Computational Environment & Human–LLM Collaboration Basics

------

## Chapter Overview

This practice chapter serves as the **entry point** to computational social science work with large language models (LLMs).

The goal is **not** to master Python syntax, but to establish a *research-ready workflow* in which:

- Jupyter Notebook functions as a **research notebook** (记录假设、代码、结果与解释)
- Python is used as a **thinking tool** for simple social-science-relevant tasks
- Large Language Models act as **interactive collaborators** for debugging, explanation, and iteration

By the end of this chapter, students should feel comfortable *working inside* a notebook, experimenting with code, and communicating errors clearly to an AI assistant.

------

## Learning Objectives

After completing this practice chapter, you should be able to:

1. **Operate a computational research environment**
   - Launch and use Jupyter Notebook (local or Google Colab)
   - Distinguish Markdown cells from Code cells
   - Execute, modify, and re-run cells safely
2. **Use Python for basic social-science tasks**
   - Define variables and perform simple calculations
   - Write and call simple functions
   - Use conditional logic (`if / elif / else`) to encode classification rules
3. **Understand libraries and imports**
   - Explain what a *library / package* is
   - Import commonly used libraries (`numpy`, `pandas`, `matplotlib`)
   - Recognize the meaning of `import ... as ...`
4. **Think vectorially with NumPy**
   - Treat data as arrays rather than single values
   - Apply mathematical operations to entire datasets at once
   - Use boolean indexing instead of `for` loops
5. **Collaborate with LLMs for debugging**
   - Read error messages rather than ignore them
   - Provide full error traces to an AI assistant
   - Evaluate and adapt AI-suggested fixes

------

## Practice Environment

You may complete this chapter in **either** of the following environments:

- **Local Jupyter Notebook**
  - Python environment managed via Anaconda / Miniconda
- **Google Colab**
  - No local installation required

The tasks are environment-agnostic; file paths and outputs may differ slightly.

------

## Conceptual Framing (Very Important)

### Jupyter Notebook as a Research Notebook

In this course, a Jupyter Notebook is **not** treated as an IDE.

Instead, it is:

- A **lab notebook** for computational social science
- A place where *text, code, output, and interpretation coexist*
- A record that can be read, reproduced, and audited by others

Markdown cells are as important as code cells.

------

### Programming as Interaction, Not Memorization

You are **not expected** to memorize Python syntax.

What *is* expected:

- You can explain *what a piece of code is doing*
- You can modify existing code with purpose
- You can ask an LLM precise questions when things go wrong

> Programming here is an **interactive reasoning process**, not a test of recall.

------

## Estimated Time

- Core tasks: **60–90 minutes**
- Optional challenges: **+30 minutes**
- Debugging time is variable and expected

------

## Deliverable

A single Jupyter Notebook file containing:

- Properly rendered Markdown sections
- Executed code cells with visible output
- Evidence of debugging and AI-assisted reasoning