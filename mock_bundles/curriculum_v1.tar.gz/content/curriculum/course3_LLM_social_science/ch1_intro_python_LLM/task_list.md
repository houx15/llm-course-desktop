# Practice Chapter 1 — Task List

## Task Categories

- **Core Tasks**: required
- **Advanced Tasks**: optional but recommended
- **Scaffolding Tasks**: for troubleshooting and understanding

------

## Core Tasks (Must Complete)

### Task 1: Markdown-Based Self Introduction

**Task ID:** `markdown_introduction`
**Type:** Core

Create a new Jupyter Notebook and, in the **first Markdown cell**, include:

- Level-1 heading: your name
- Level-3 heading: your research interests
- Unordered list: three skills you want to gain from this course
- One bolded sentence: a personal motto
- One hyperlink: university homepage or personal page
- A horizontal rule at the bottom

Run the cell and verify correct rendering.

------

### Task 2: Python Variables and Basic Computation

**Task ID:** `basic_variables_age`
**Type:** Core

In a code cell:

- Define:
  - `year_of_birth`
  - `current_year`
- Compute `age`
- Define a string variable `hometown`
- Print a full self-introduction using:
  - plain `print()`
  - an f-string

**Reflection (Markdown):**

- What changes when using an f-string?
- Why might this matter for readability?

------

### Task 3: Writing and Using Functions

**Task ID:** `functions_intro`
**Type:** Core

#### (a) Temperature Conversion

- Define `celsius_to_fahrenheit(c)`
- Call it with input `25`
- Print the result

#### (b) Generational Classification (Advanced Logic)

- Define `ge_gene(age)`
- Use `if / elif / else` to return age-group labels
- Test the function with at least three ages

------

### Task 4: NumPy Arrays and Descriptive Statistics

**Task ID:** `numpy_survey_simulation`
**Type:** Core

- Import NumPy as `np`
- Generate an array of 50 random integers between 18 and 65
- Compute and print:
  - mean
  - minimum
  - maximum
  - standard deviation

------

### Task 5: Vectorized Operations with NumPy

**Task ID:** `numpy_vectorization`
**Type:** Core

- Use boolean indexing to extract ages > 40

- Compute a subsidy array using:

  ```
  subsidy = 100 + age * 1.5
  ```

- Print the first five values

**Markdown explanation required:**

- What does “vectorized” mean?
- Why avoid `for` loops here?

------

### Task 6: Debugging with LLM Assistance

**Task ID:** `llm_debugging`
**Type:** Core

#### (a) Syntax Error

- Intentionally write invalid Python code
- Copy the **full error message**
- Ask an LLM to explain and fix it
- Apply the fix

#### (b) Type Error (Advanced)

- Trigger a string–integer concatenation error
- Ask the LLM:
  - why the error occurs
  - multiple valid solutions
- Try at least one solution

------

## Advanced Tasks (Optional)

### Task 7: File Write and Read

**Task ID:** `file_io_intro`
**Type:** Advanced

- Write your self-introduction to `my_profile.txt`
- Read the file and print its contents
- Observe whether `with open(...)` is used
- Explain why this pattern is recommended

------

## Scaffolding Tasks (If Needed)

- Practice Markdown syntax separately
- Ask the LLM to explain:
  - error tracebacks
  - NumPy array shapes
  - differences between list and array